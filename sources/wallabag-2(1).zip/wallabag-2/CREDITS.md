wallabag is mainly developed by [Nicolas Lœuillet](https://github.com/nicosomb), [@j0k3r](https://github.com/j0k3r) and [@tcitworld](https://github.com/tcitworld) under the MIT License.

Thank you [to others contributors](https://github.com/wallabag/wallabag/graphs/contributors).
