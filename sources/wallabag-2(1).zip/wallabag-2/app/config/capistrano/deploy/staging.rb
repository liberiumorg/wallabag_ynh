set :branch, 'v2'
set :deploy_to, '/var/www/v2.wallabag.org/web/'
