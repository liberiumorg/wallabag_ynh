<?php

namespace Wallabag\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WallabagApiBundle extends Bundle
{
}
