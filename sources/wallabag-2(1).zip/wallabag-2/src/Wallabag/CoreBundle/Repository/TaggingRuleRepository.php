<?php

namespace Wallabag\CoreBundle\Repository;

use Doctrine\ORM\EntityRepository;

class TaggingRuleRepository extends EntityRepository
{
}
