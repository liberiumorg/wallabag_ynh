<?php

namespace Wallabag\CoreBundle\Repository;

use Doctrine\ORM\EntityRepository;

class ConfigRepository extends EntityRepository
{
}
