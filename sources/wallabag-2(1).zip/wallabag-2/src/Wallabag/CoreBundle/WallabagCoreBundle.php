<?php

namespace Wallabag\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WallabagCoreBundle extends Bundle
{
}
