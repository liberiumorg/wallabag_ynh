<?php

namespace Wallabag\AnnotationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WallabagAnnotationBundle extends Bundle
{
}
