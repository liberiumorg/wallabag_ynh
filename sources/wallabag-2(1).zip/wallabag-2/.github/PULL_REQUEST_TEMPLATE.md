| Q             | A
| ------------- | ---
| Bug fix?      | yes|no
| New feature?  | yes|no
| BC breaks?    | yes|no
| Deprecations? | yes|no
| Tests pass?   | yes|no
| Documentation | yes|no
| Translation   | yes|no
| Fixed tickets | comma-separated list of tickets fixed by the PR, if any
| License       | MIT
