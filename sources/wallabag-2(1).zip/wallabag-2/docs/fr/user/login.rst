Se connecter
============

Votre compte est maintenant actif, félicitations !

Pour vous connecter à wallabag, remplissez le formulaire de connexion.

Si vous êtes sur un ordinateur de confiance et que vous souhaitez rester connecté
vous pouvez cocher la case ``Restez connecté`` : wallabag se souviendra de vous pour un an.

.. image:: ../../img/user/login_form.png
   :alt: Formulaire de connexion
   :align: center

Foire aux questions
-------------------

J'ai oublié mon mot de passe
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Vous pouvez réinitialiser votre mot de passe en cliquant sur ``Mot de passe oublié ?``,
sur la page de connexion. Ensuite, renseignez votre adresse email ou votre nom d'utilisateur,
un email vous sera envoyé.
