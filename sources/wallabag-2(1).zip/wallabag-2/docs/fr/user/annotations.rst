Annotations
===========

Sur chaque article que vous lisez, vous pouvez écrire des annotations. Puisqu'une image vaut mieux qu'un long discours,
voici ce que ça donne.

Sélectionnez la zone du texte que vous souhaitez annoter et cliquez sur le crayon :

.. image:: ../../img/user/annotations_1.png
   :alt: Sélectionnez votre texte
   :align: center

Ensuite, écrivez votre annotation :

.. image:: ../../img/user/annotations_2.png
   :alt: Écrivez votre annotation
   :align: center

Le texte est maintenant surligné et vous pouvez lire le annotation en le survolant avec votre souris.

.. image:: ../../img/user/annotations_3.png
   :alt: Lisez votre annotation
   :align: center

Vous pouvez créer autant de annotations que vous le souhaitez.
