Erreur durant la récupération des articles
==========================================

Pourquoi la récupération des articles échoue ?
----------------------------------------------

Il peut y avoir plusieurs raisons :

- problème de connexion internet
- wallabag ne peut pas récupérer le contenu à cause de la structure du site web

Comment puis-je aider pour réparer ça ?
---------------------------------------

- `en nous envoyant un email avec l'URL de l'article <mailto:hello\@wallabag.org>`_
- en essayant de réparer cet article par vous-même :) en créant un fichier pour l'article.
  Vous pouvez utiliser `cet outil <http://siteconfig.fivefilters.org/>`__.

Comment puis-je réessayer de récupérer le contenu ?
---------------------------------------------------

Si wallabag échoue en récupérant l'article, vous pouvez cliquer sur le bouton suivant
(le troisième sur l'image ci-dessous).

.. image:: ../../img/user/refetch.png
   :alt: Réessayer de récupérer le contenu
   :align: center
