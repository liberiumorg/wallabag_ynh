Télécharger des articles
========================

Vous pouvez télécharger chaque article dans plusieurs formats : ePUB, MOBI, PDF, XML, JSON, CSV.

Lorsque vous lisez un article, cliquez sur cette icône dans la barre latérale :

.. image:: ../../img/user/download_article.png
   :alt: Télécharger l'article
   :align: center

Vous pouvez aussi télécharger une catégorie (non lus, favoris, lus) dans ces formats.
Par exemple, dans la vue **Non lus**, cliquez sur cette icône dans la barre supérieure :

.. image:: ../../img/user/download_articles.png
   :alt: Télécharger l'article
   :align: center
