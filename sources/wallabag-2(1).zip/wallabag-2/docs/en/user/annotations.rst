Annotations
===========

In each article you read, you can write annotations. It's easier to understand with some pictures.

Select the part of the article that you want to annotate and click on the pencil:

.. image:: ../../img/user/annotations_1.png
   :alt: Select your text
   :align: center

Then, write your annotation:

.. image:: ../../img/user/annotations_2.png
   :alt: Write your annotation
   :align: center

The text is now highlighted and you can read your annotation if you move the mouse cursor over it.

.. image:: ../../img/user/annotations_3.png
   :alt: Read your annotation
   :align: center

You can create as many annotations as you wish.
