Login
=====

Your account is now enabled, congratulations!

To login to wallabag, fill the form on login page.

If you are on your personal computer and you want to stay connected,
you can check the ``Keep me logged in`` checkbox: wallabag will remember you for one year.

.. image:: ../../img/user/login_form.png
   :alt: Login form
   :align: center

Frequently asked questions
--------------------------

I forgot my password
~~~~~~~~~~~~~~~~~~~~

You can reset your password by clicking on ``Forgot your password?`` link,
on the login page. Then, fill the form with your email address or your username,
you'll receive an email to reset your password.
