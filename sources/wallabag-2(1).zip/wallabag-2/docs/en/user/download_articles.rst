Download articles
=================

You can download each article in several formats: ePUB, MOBI, PDF, XML, JSON, CSV.

On the article view, click on this icon, in the sidebar:

.. image:: ../../img/user/download_article.png
   :alt: download article
   :align: center

You can also download a full category (unread, starred, archive) in these formats.
For example, on **Unread** view, click on this icon in the top bar:

.. image:: ../../img/user/download_articles.png
   :alt: download articles
   :align: center
